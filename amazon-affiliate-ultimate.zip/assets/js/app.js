
const TAG='stumblely-21';
fetch('data/products.json').then(r=>r.json()).then(data=>{
window.products=data;render(data);
});
function render(items){
const g=document.getElementById('products'); if(!g)return;
g.innerHTML=items.map(p=>`<div class="card bg-white p-4 rounded shadow">
<div>${p.badge}</div><h3>${p.name}</h3><p>${p.category}</p>
<button onclick="toggleFav(${p.id})">❤</button>
<button onclick="addCompare(${p.id})">Compare</button>
<a target="_blank" rel="nofollow sponsored" href="https://www.amazon.com/s?k=${encodeURIComponent(p.keyword)}&tag=${TAG}">Amazon</a>
</div>`).join('');
}
